'use client';

import React, { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { useAuth } from '@/components/FirebaseProvider';
import { collection, query, where, onSnapshot, orderBy, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '@/firebase';
import Image from 'next/image';
import { Plus, Package, TrendingUp, Users, Settings, Trash2, Edit2, Loader2, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AddProductModal } from '@/components/AddProductModal';

export default function Dashboard() {
  const { user, profile, loading: authLoading } = useAuth();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'products'), 
      where('farmerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProducts(docs);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching farmer products:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja remover este produto?')) {
      try {
        await deleteDoc(doc(db, 'products', id));
      } catch (error) {
        console.error("Error deleting product:", error);
      }
    }
  };

  const toggleStatus = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'available' ? 'sold_out' : 'available';
    try {
      await updateDoc(doc(db, 'products', id), { status: newStatus });
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const becomeFarmer = async () => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), { role: 'farmer' });
      window.location.reload();
    } catch (error) {
      console.error("Error becoming farmer:", error);
    }
  };

  if (authLoading) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="w-10 h-10 text-emerald-600 animate-spin" />
    </div>
  );

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
        <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mb-6">
          <Users className="w-10 h-10 text-stone-300" />
        </div>
        <h1 className="text-3xl font-serif font-bold mb-4">Acesso Restrito</h1>
        <p className="text-stone-500 mb-8 max-w-xs">Faça login para gerenciar os seus produtos e vendas.</p>
        <button onClick={() => window.location.href = '/'} className="bg-emerald-600 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-emerald-100 transition-all active:scale-95">Voltar ao Mercado</button>
      </div>
    );
  }

  if (profile?.role !== 'farmer') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center bg-stone-50">
        <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mb-8">
          <Package className="w-12 h-12 text-emerald-700" />
        </div>
        <h1 className="text-3xl font-serif font-bold mb-4 text-stone-900">Quer vender os seus produtos?</h1>
        <p className="text-stone-600 mb-10 max-w-sm text-lg">Ative a sua conta de agricultor para começar a vender no AgroMoz. É rápido e simples.</p>
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
          <button 
            onClick={becomeFarmer} 
            className="flex-1 bg-emerald-700 text-white px-8 py-5 rounded-xl font-bold shadow-lg hover:bg-emerald-800 transition-all active:scale-95"
          >
            Ativar Agora
          </button>
          <button 
            onClick={() => window.location.href = '/'}
            className="flex-1 px-8 py-5 border border-stone-300 rounded-xl font-bold text-stone-700 hover:bg-white transition-all"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-stone-50 pb-20">
      <Navbar />
      
      <header className="bg-white border-b border-stone-200 pt-16 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
              <h1 className="text-4xl font-serif font-bold text-stone-900 mb-3">Olá, {profile?.displayName?.split(' ')[0]}</h1>
              <p className="text-lg text-stone-600">Aqui pode gerenciar os seus produtos e vendas.</p>
            </div>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="bg-emerald-700 text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center space-x-3 hover:bg-emerald-800 transition-all shadow-lg"
            >
              <Plus className="w-6 h-6" />
              <span>Novo Produto</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-16">
            <StatCard icon={<Package className="text-emerald-700" />} label="Produtos" value={products.length.toString()} />
            <StatCard icon={<TrendingUp className="text-blue-700" />} label="Vendas" value="0 MZN" />
            <StatCard icon={<Users className="text-orange-700" />} label="Interessados" value="0" />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="bg-white rounded-[2rem] border border-stone-200 overflow-hidden shadow-sm">
          <div className="px-8 py-6 border-b border-stone-100 flex items-center justify-between">
            <h2 className="text-xl font-bold text-stone-900">As Suas Listagens</h2>
            <div className="flex items-center space-x-2 text-sm text-stone-500">
              <Settings className="w-4 h-4" />
              <span>Configurações</span>
            </div>
          </div>

          {loading ? (
            <div className="p-20 flex justify-center">
              <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
            </div>
          ) : products.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50/50 text-stone-500 text-xs font-bold uppercase tracking-wider">
                    <th className="px-8 py-4">Produto</th>
                    <th className="px-8 py-4">Tipo</th>
                    <th className="px-8 py-4">Preço</th>
                    <th className="px-8 py-4">Estado</th>
                    <th className="px-8 py-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="px-8 py-5">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-xl bg-stone-100 overflow-hidden flex-shrink-0 relative">
                            <Image 
                              src={p.imageUrl || `https://picsum.photos/seed/${p.title}/100/100`} 
                              alt={p.title} 
                              fill
                              className="object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <p className="font-bold text-stone-900">{p.title}</p>
                            <p className="text-xs text-stone-500 flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {p.location}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <span className="text-sm text-stone-600">{p.category}</span>
                      </td>
                      <td className="px-8 py-5">
                        <p className="text-sm font-bold text-stone-900">{p.price} MZN</p>
                        <p className="text-[10px] text-stone-400 uppercase">por {p.unit}</p>
                      </td>
                      <td className="px-8 py-5">
                        <button 
                          onClick={() => toggleStatus(p.id, p.status)}
                          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            p.status === 'available' 
                              ? 'bg-emerald-100 text-emerald-700' 
                              : 'bg-stone-200 text-stone-600'
                          }`}
                        >
                          {p.status === 'available' ? 'À Venda' : 'Vendido'}
                        </button>
                      </td>
                      <td className="px-8 py-5 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button className="p-2 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(p.id)}
                            className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-20 text-center">
              <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-stone-300" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 mb-1">Nenhum produto listado</h3>
              <p className="text-stone-500 mb-6">Comece a vender adicionando o seu primeiro produto.</p>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="text-emerald-600 font-bold hover:underline"
              >
                Adicionar agora
              </button>
            </div>
          )}
        </div>
      </div>

      <AddProductModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </main>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex items-center space-x-4">
      <div className="w-12 h-12 rounded-2xl bg-stone-50 flex items-center justify-center">
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-stone-400 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-serif font-bold text-stone-900">{value}</p>
      </div>
    </div>
  );
}
